#include <stdio.h>
#include <stdlib.h>

int main()
{
  char vec[5]= {'a', 'e', 'i', 'o', 'u'};

  printf("%c", vec[4]);




    return 0;
}
